"""Agent 2: Chunker."""

from .text_chunker import TextChunker

__all__ = ["TextChunker"]
